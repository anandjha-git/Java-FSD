
public class BinarySearch {
public int binarySearch(int arr[], int key){
	int left = 0, right = arr.length - 1;
	while (left <= right)
    {
		int mid = (left + right) / 2;
        if (key == arr[mid]) {
            return mid;
        }
        else if (key < arr[mid]) {
            right = mid - 1;
        }
        else {
            left = mid + 1;
        }
    }
    return -1;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={2,4,6,7,8,12,34,65,89};
		int searchKey=34;
		BinarySearch obj = new BinarySearch();
		int find =obj.binarySearch(arr,searchKey);
		if(find==-1){
			System.out.println("Not Found");
		}
		else{
			System.out.println(searchKey +" is available at "+find+" index.. Thank you");
		}
	}

}
//Output
/*
34 is available at 6 index.. Thank you
*/