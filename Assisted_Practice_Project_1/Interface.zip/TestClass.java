interface Printable{  
void print();  
}  
interface Showable{  
void show();  
}  
public class TestClass  implements Printable,Showable {
	public void print(){
		System.out.println("Printable Interface");
		}  
	public void show(){
		System.out.println("Showable Interface");
		}  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestClass obj = new TestClass();
		obj.print();  
		obj.show();  

	}

}
//Output
/*
Printable Interface
Showable Interface
*/