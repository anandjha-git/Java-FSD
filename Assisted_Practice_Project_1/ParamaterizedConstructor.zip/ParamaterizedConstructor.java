
public class ParamaterizedConstructor {
	private int Id;
	private String Name;
	ParamaterizedConstructor(int Id, String Name){
		System.out.println("This is Parameterized Constructor.");
		this.Id=Id;
		this.Name=Name;
	}
	void information(){
		System.out.println("Id : "+Id+" Name : "+Name);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ParamaterizedConstructor obj= new ParamaterizedConstructor(102, "Shivam");
		new ParamaterizedConstructor(100, "Aman");
		ParamaterizedConstructor obj2 = new ParamaterizedConstructor(0,null);
		obj2.information();
		ParamaterizedConstructor obj1= new ParamaterizedConstructor(101, "Pawan");
		obj1.information();
	}

}
//Outpt
/*
This is Parameterized Constructor.
This is Parameterized Constructor.
This is Parameterized Constructor.
Id : 0 Name : null
This is Parameterized Constructor.
Id : 101 Name : Pawan
*/