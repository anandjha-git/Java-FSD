
public class ThreadClass extends Thread {
	
	public void run(){
		System.out.println("Thread  is Running.");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadClass obj = new ThreadClass();
			obj.start();
		
	}

}
//Output
/*
Thread  is Running.
*/