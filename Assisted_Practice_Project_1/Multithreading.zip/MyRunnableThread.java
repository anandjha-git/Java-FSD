
public class MyRunnableThread implements Runnable {
	public static int count=0;
	public MyRunnableThread(){
		
	}
	public void run(){
		while(MyRunnableThread.count<=10){
			try{
				System.out.println("Expl Thread: "+(++MyRunnableThread.count));
				Thread.sleep(100);
			}catch(InterruptedException iex){
				System.out.println("Exception in Thread : "+iex.getMessage());
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main Thread is Starting . .  .. . ");
		MyRunnableThread objMrt = new MyRunnableThread();
		Thread t  = new Thread(objMrt);
		t.start();
		while(MyRunnableThread.count<=10){
			try{
				System.out.println("Main Thread: "+(++MyRunnableThread.count));
				Thread.sleep(100);
			}catch(InterruptedException iex){
				System.out.println("Exception in Thread : "+iex.getMessage());
			}
		}
		System.out.println("End of MAin Thread .. . ");
	}

}
//Output
/*
 Starting Main Thread...
Main Thread: 1
Expl Thread: 2
Main Thread: 3
Expl Thread: 3
Main Thread: 4
Expl Thread: 5
Expl Thread: 6
Main Thread: 6
Expl Thread: 8
Main Thread: 7
Expl Thread: 9
Main Thread: 10
End of Main Thread...
Expl Thread: 11
*/
