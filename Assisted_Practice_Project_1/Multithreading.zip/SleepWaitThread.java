
public class SleepWaitThread {
	private static Object Lock = new Object();
	
	public static void main(String[] args)throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
		System.out.println("Thread "+Thread.currentThread().getName() +" is woken after sleep 3 second");
		synchronized(Lock){
			Lock.wait(2000);
			System.out.println("Object "+Lock+" is woken after waiting for 2 second");
		}

	}

}
//Output
/*
Thread main is woken after sleep 3 second
Object java.lang.Object@15db9742 is woken after waiting for 2 second
*/