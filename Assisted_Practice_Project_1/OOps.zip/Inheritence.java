class Employee{
	String Name;
	double salary;
}
class SoftEng extends Employee{
	double bonus = 5000;
	public SoftEng(String Name, double salary, double bonus){
		this.Name=Name;
		this.salary=salary;
		this.bonus=bonus;
	}
	public void getInfo(){
		System.out.println("Employee Name : "+Name+", Salary : "+salary+ " and Bonus : "+bonus);
	}
}
public class Inheritence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SoftEng obj = new SoftEng("Anand Kumar Jha", 15450.78,2326.80);
		obj.getInfo();
		

	}

}
//Output
/*
Employee Name : Anand Kumar Jha, Salary : 15450.78 and Bonus : 2326.8
*/