
public class Vehicle {
	String Model;
	String Color;
	String Name;
	public Vehicle(String Model, String Color, String Name){
		this.Model=Model;
		this.Color= Color;
		this.Name=Name;
	}
	public String getModel()
	{
		return Model;
	}
	public String getName(){
		return Name;
	}
	public String getColor(){
		return Color;
	}
	public void getDetail()
	{
		System.out.println("Hi, I have a car having Model : "+getModel()+", Name : "+getName()+ " and Color : "+getColor());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle car = new Vehicle("BMWXS", "Black", "BMW");
		car.getDetail();
		

	}

}
//Output
/*
Hi, I have a car having Model : BMWXS, Name : BMW and Color : Black
*/