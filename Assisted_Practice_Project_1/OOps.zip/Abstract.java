abstract class MotorBike {
	String color;
  abstract void brake();
  public MotorBike(String color){
	  this.color=color;
	  System.out.println("MotorBike Class");
  }
  public String getColor(){
	  return color;
  }
}

class SportsBike extends MotorBike {
    public SportsBike(String color){
    	super(color);
    	System.out.println("SportsBike Class");
    }
 
  public void brake() {
    System.out.println("SportsBike Brake");
  }
  public String getColor(){
	  return color;
  }
}

class MountainBike extends MotorBike {
	 public MountainBike(String color){
	    	super(color);
	    	System.out.println("MountainBike Class");
	    }
  public void brake() {
    System.out.println("MountainBike Brake");
  }
}
public class Abstract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MountainBike obj1 = new MountainBike("red");
	    obj1.brake();
	    System.out.println("Color is : "+obj1.getColor());
	    SportsBike obj2 = new SportsBike("white");
	    obj2.brake();
	    System.out.println("Color is : "+obj2.getColor());

	}

}
//Output
/*
MotorBike Class
MountainBike Class
MountainBike Brake
Color is : red
MotorBike Class
SportsBike Class
SportsBike Brake
Color is : white
*/