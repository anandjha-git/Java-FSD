
public class Encapsulation {
private String name;
private int age;
private double height;
public void setInfo(String newName, int newAge, double newHeight){
	name=newName;
	age=newAge;
	height=newHeight;
}
public void getInfo(){
	System.out.println("My name is "+name+", age is "+age+" and height in ft "+height);
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulation obj =new Encapsulation();
		obj.setInfo("Anand Kumar Jha", 29, 6.2);
		obj.getInfo();
	}

}
//Output
/*
My name is Anand Kumar Jha, age is 29 and height in ft 6.2
*/