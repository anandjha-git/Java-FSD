
public class Polymorphism {
public double mul(double a, double b){
	return a*b;
}
public int mul(int a, int b, int c){
	return a*b*c;
}
public int mul(int a, int b, int c, int d){
	return a*b*c*d;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Polymorphism obj = new Polymorphism();
		System.out.println("Answer : "+obj.mul(3,5));
		System.out.println("Answer : "+obj.mul(3,5,7));
		System.out.println("Answer : "+obj.mul(3,5,9,2));

	}

}
//Output
/*
Answer : 15.0
Answer : 105
Answer : 270
*/