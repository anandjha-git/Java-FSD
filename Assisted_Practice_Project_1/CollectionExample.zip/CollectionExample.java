import java.util.*;
import java.io.*; 
import java.util.*; 

public class CollectionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//ArrayList
		System.out.println("All About ArrayList");
		ArrayList<String> city=new ArrayList<String>();
		city.add("Delhi");
		city.add("Ghaziabad");
		city.add(null);
		city.add("Gurugram");
		System.out.println("Elements in ArrayList Are : "+city);
		System.out.println("Size of ArrayList is  : "+city.size());
		city.add("Pune");
		city.add(1, "Patna"); // Add Element At Position
		System.out.println("Elelments in ArrayList Are : "+city); 
		city.add("Banglore");
		System.out.println("Elelments in ArrayList Are : "+city); 
		System.out.println("Size of ArrayList is  : "+city.size());
		city.remove(2); //Remove Element from 2nd Index 
		System.out.println("Get Element at Index : "+city.get(3)); // Get Element
		System.out.println("Elelments in ArrayList Are : "+city);
		for(int i=0; i<city.size();i++) { // Display Elements one by one 
			System.out.println(city.get(i));
		}
		
		//Vector
		System.out.println("\nAll About Vector");
		Vector<Integer> number = new Vector<Integer>();
		number.add(10);
		number.add(20);
		number.add(30);
		number.add(null);
		number.add(40);
		System.out.println("Elements in Vector Are : "+number);
		number.remove(1); //Remove Element from Index
		System.out.println("Elements in Vector Are : "+number);
		for(int i=0; i<number.size();i++) { // Display Elements one by one 
			System.out.println(number.get(i));
		}
		
		//LinkedList
		System.out.println("\nAll About LinkedList");
		LinkedList<Integer> LL = new LinkedList<Integer>();
		LL.add(10);
		LL.add(null);
		LL.add(20);
		LL.add(30);
		LL.add(40);
		System.out.println("Elements in LinkedList Are : "+LL);
		LL.remove(2); //Remove Element from Index
		System.out.println("Elements in LinkedList Are : "+LL);
		for(int i=0; i<LL.size();i++) { // Display Elements one by one 
			System.out.println(LL.get(i));
		}
		System.out.println("Display Elements By Using Iterator");
		Iterator<Integer> itr = LL.iterator();// Display Elements By Using Iterator
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		//HashSet
		System.out.println("\nAll About HashSet");
		HashSet<Integer> HS = new HashSet<Integer>();
		HS.add(11);
		HS.add(20);
		HS.add(83);
		HS.add(44);
		HS.add(null);
		System.out.println("Elements in HashSet Are : "+HS);
		System.out.println("Display Elements By Using Iterator");
		Iterator<Integer> itr1 = HS.iterator();// Display Elements By Using Iterator
		while(itr1.hasNext()) {
			System.out.println(itr1.next());
		}
		
		//LinkedHashSet
		System.out.println("\nAll About LinkedHashSet");
		LinkedHashSet<Integer> LHS = new LinkedHashSet<Integer>();
		LHS.add(11);
		LHS.add(20);
		LHS.add(null);
		LHS.add(83);
		LHS.add(44);
		System.out.println("Elements in LinkedHashSet Are : "+LHS);
		System.out.println("Display Elements By Using Iterator");
		Iterator<Integer> itr2 = LHS.iterator();// Display Elements By Using Iterator
		while(itr2.hasNext()) {
			System.out.println(itr2.next());
		}
	}

}

//Output
/*
All About ArrayList
Elements in ArrayList Are : [Delhi, Ghaziabad, null, Gurugram]
Size of ArrayList is  : 4
Elelments in ArrayList Are : [Delhi, Patna, Ghaziabad, null, Gurugram, Pune]
Elelments in ArrayList Are : [Delhi, Patna, Ghaziabad, null, Gurugram, Pune, Banglore]
Size of ArrayList is  : 7
Get Element at Index : Gurugram
Elelments in ArrayList Are : [Delhi, Patna, null, Gurugram, Pune, Banglore]
Delhi
Patna
null
Gurugram
Pune
Banglore

All About Vector
Elements in Vector Are : [10, 20, 30, null, 40]
Elements in Vector Are : [10, 30, null, 40]
10
30
null
40

All About LinkedList
Elements in LinkedList Are : [10, null, 20, 30, 40]
Elements in LinkedList Are : [10, null, 30, 40]
10
null
30
40
Display Elements By Using Iterator
10
null
30
40

All About HashSet
Elements in HashSet Are : [null, 83, 20, 11, 44]
Display Elements By Using Iterator
null
83
20
11
44

All About LinkedHashSet
Elements in LinkedHashSet Are : [11, 20, null, 83, 44]
Display Elements By Using Iterator
11
20
null
83
44
*/