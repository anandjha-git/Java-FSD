package protectedSpecifier;

public class AccessModifier2 extends ProtectedModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifier2 obj = new AccessModifier2();
		obj.num=90;
		obj.display();

	}

}
 class ProtectedModifier{
	protected int num;
	protected void display(){
		System.out.println("This is Protected Specifier Method");
		System.out.println("This is Protected Variable : "+num);
	}
}

//Output
/*
This is Protected Specifier Method
This is Protected Variable : 90
*/