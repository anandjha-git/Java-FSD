
public class InnerClass {
	private String tip = "Welcome";
	void message() {
	class Inner{
		void display() {
			System.out.println(tip + " This Is Inner Class");
			}
		}
	Inner in= new Inner();
	in.display();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerClass obj = new InnerClass();
		obj.message();
		Outer.Inner oi= new Outer().new Inner();
		oi.display();
		Outer otr = new Outer();
		Outer.Inner inr = otr.new Inner();
		inr.display();
				
	}

}

class Outer{
	class Inner{
		void display() {
			System.out.println("This Is Nested Class");
		}
	}
}

//Output
/*
Welcome This Is Inner Class
This Is Nested Class
This Is Nested Class
*/