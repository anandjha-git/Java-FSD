package publicSpecifier1;

public class PublicClass1 {
	public void display(){
		System.out.println("This is Public Specifier");
	}
}
