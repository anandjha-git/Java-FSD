
abstract class Anonmous{
	public abstract void message() ;
	
}

public class AnonymousClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Anonmous obj = new Anonmous() {
			public void message() {
				System.out.println("Defined as Anonymous Inner Class");
			}
		};
		obj.message();
	}

}
//Output
/*
Defined as Anonymous Inner Class
*/