
public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1 D Array
		int a[]= {1,2,3,4,5,6,7,8,9};
		for(int i=0;i<9;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}
		
		//2D Array-- 
		int[][] b = {
	            {1,2,3}, 
	            {4,5,6},
	            {7,8,9}
	            };
	      System.out.println("Elements of array b : ");
	      for(int i=0;i<3;i++) {
	    	  for(int j=0;j<3;j++) {
	    		  System.out.print(b[i][j]+"\t");
	    	  }
	    	  System.out.println();
	      }



	}

}

//Output
/*
Elements of array a: 1
Elements of array a: 2
Elements of array a: 3
Elements of array a: 4
Elements of array a: 5
Elements of array a: 6
Elements of array a: 7
Elements of array a: 8
Elements of array a: 9
Elements of array b : 
1	2	3	
4	5	6	
7	8	9	
*/