
public class DefaultConstructor {
	static int Id;
	static String EmpName;
	DefaultConstructor(){
		System.out.println("This is Default Constructor.");
		System.out.println("Id : "+Id+" and Name : "+EmpName);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultConstructor obj1= new DefaultConstructor();
		new DefaultConstructor();
		Id=101;
		EmpName = "Anand";
		new DefaultConstructor();
		
		
		

	}

}

//Output
/*
This is Default Constructor.
Id : 0 and Name : null
This is Default Constructor.
Id : 0 and Name : null
This is Default Constructor.
Id : 101 and Name : Anand
*/