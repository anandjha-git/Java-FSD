import java.util.*;

public class MapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Hashmap
				HashMap<Integer,String> hm=new HashMap<Integer,String>();      
			      hm.put(1,"Anand");    
			      hm.put(2,"Banti");    
			      hm.put(3,"Chetna");   
			       
			      System.out.println("\nThe elements of Hashmap are ");  
			      for(Map.Entry m:hm.entrySet()){    
			       System.out.println(m.getKey()+" "+m.getValue());    
			      }
			      
			     //HashTable
			       
			      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
			      
			      ht.put(4,"Rikki");  
			      ht.put(5,"Sonam");  
			      ht.put(6,"Lado");  
			      ht.put(7,"Krishna");  

			      System.out.println("\nThe elements of HashTable are ");  
			      for(Map.Entry n:ht.entrySet()){    
			       System.out.println(n.getKey()+" "+n.getValue());    
			      }
			      
			      
			      //TreeMap
			      
			      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
			      map.put(8,"Nikhil");    
			      map.put(9,"Mohan");    
			      map.put(10,"Babu");       
			      
			      System.out.println("\nThe elements of TreeMap are ");  
			      for(Map.Entry l:map.entrySet()){    
			       System.out.println(l.getKey()+" "+l.getValue());    
			      }    
			   


	}

}

//Output
/*

The elements of Hashmap are 
1 Anand
2 Banti
3 Chetna

The elements of HashTable are 
7 Krishna
6 Lado
5 Sonam
4 Rikki

The elements of TreeMap are 
8 Nikhil
9 Mohan
10 Babu
*/