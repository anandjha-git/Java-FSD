package publicSpecifier1;
//import publicSpecifier.*;
public class PublicClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PublicClass1 obj = new PublicClass1();
		obj.display();
	}

}
