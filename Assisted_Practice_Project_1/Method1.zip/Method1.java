
public class Method1 {
static int method(int x, int y){
	return (x+y*y+y);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The method() calling : "+method(6,4));
	}

}

//Output
/*
The method() calling : 26
*/