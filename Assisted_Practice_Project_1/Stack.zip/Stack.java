
public class Stack {
	static final int MAX = 1000; 
	int top; 
	int stack[] = new int[MAX];  
	boolean isStackEmpty(){
		return (top<0);
	}
	Stack(){
		top=-1;
	}
	void push(int data){
		if(top>=MAX-1){
			System.out.println("Stack is Overflow");
		}
		else{
			stack[++top]=data;
			System.out.println(data+" is Pushed in Stack");
		}
	}
	void pop(){
		if(top<0){
			System.out.println("Stack is Underflow");
		}
		else{
			System.out.println(stack[top--]+ " is Popped");
		}
	}
	void display(){
		if(top<0){
			System.out.println("Stack is UnderFlow");
			return;
		}
		int temp=top;
		System.out.println("Elements of Stacks are : ");
		while(temp>=0){
			System.out.print(stack[temp--]+" ");
		}
		System.out.println();
	}
	void peek(){
		if(top<0)
			System.out.println("Stack is Underflow");
		else
			System.out.println("The element at top is "+stack[top]);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack stack = new Stack();
		if(stack.isStackEmpty())
			System.out.println("Now, Stack is Empty");
		stack.pop();
		stack.peek();
		stack.display();
		stack.push(10);
		stack.push(45);
		stack.push(12);
		stack.push(9);
		stack.display();
		stack.peek();
		stack.push(65);
		stack.display();
		stack.pop();
		stack.display();
	}

}
//Output
/*
Now, Stack is Empty
Stack is Underflow
Stack is Underflow
Stack is UnderFlow
10 is Pushed in Stack
45 is Pushed in Stack
12 is Pushed in Stack
9 is Pushed in Stack
Elements of Stacks are : 
9 12 45 10 
The element at top is 9
65 is Pushed in Stack
Elements of Stacks are : 
65 9 12 45 10 
65 is Popped
Elements of Stacks are : 
9 12 45 10 
*/