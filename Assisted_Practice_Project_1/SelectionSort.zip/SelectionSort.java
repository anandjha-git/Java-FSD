
public class SelectionSort {
    public static void selectionSort(int[] arr){

        for(int i=0;i<arr.length-1;i++){

            int index =i;
            for(int j=i+1;j<arr.length;j++){
                if(arr[j]<arr[index]){

                    index =j;
                }

            }
            int smallNumber = arr[index];
            arr[index]= arr[i];
            arr[i]= smallNumber;
        }

    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={2,34,4,5,23,8,21,45,34,37};
		System.out.println("Before Sorting");
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		System.out.println();
		selectionSort(arr);
		System.out.println("After Sorting");
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		

	}

}
//Output
/*
Before Sorting
2 34 4 5 23 8 21 45 34 37 
After Sorting
2 4 5 8 21 23 34 34 37 45 
*/