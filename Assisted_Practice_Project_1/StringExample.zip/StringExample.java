
public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("****** All About String\n");
		String st=new String("Welcome, Hello World");
		System.out.println(st);
		System.out.println(st.length());

		//substring
		String sub=new String("Thank You");
		System.out.println(sub.substring(2));
		
		//String Comparison
		String s1="Hey";
		String s2="Hello";
		System.out.println(s1.compareTo(s2));
		//IsEmpty
		String s4="";
		System.out.println(s4.isEmpty());
		

		//toLowerCase
		String s5="Welcome to Java";
		System.out.println(s1.toLowerCase());
		
		//replace
		String s6="Ghaziacad";
		String replace=s2.replace('c', 'b');
		System.out.println(replace);

		//equals
		String x="Welcome to Pune";
		String y="WeLcOmE tO pUnE";
		System.out.println(x.equals(y));
 
		System.out.println("\n");
		System.out.println("Creating StringBuffer");
		//Creating StringBuffer and append method
		StringBuffer s=new StringBuffer("Welcome to Mumbai!");
		s.append("Happy Joining");
		System.out.println(s);

		//insert method
		s.insert(3, 'H');
		System.out.println(s);

		//replace method
		StringBuffer sb=new StringBuffer("Excelsheet");
		sb.replace(3, 6, "wyz");
		System.out.println(sb);

		//delete method
		sb.delete(4, 7);
		System.out.println(sb);
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("AllIsWell");
		sb1.append("Learning");
		System.out.println(sb1);

		System.out.println(sb1.delete(3, 5));

		System.out.println(sb1.insert(1, "Good"));

		System.out.println(sb1.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "HealthIsWeath"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("LikeMoney"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		




	}

}

//Output
/*
****** All About String

Welcome, Hello World
20
ank You
13
true
hey
Hello
false


Creating StringBuffer
Welcome to Mumbai!Happy Joining
WelHcome to Mumbai!Happy Joining
Excwyzheet
Excweet


Creating StringBuilder
AllIsWellLearning
AllWellLearning
AGoodllWellLearning
gninraeLlleWlldooGA


Conversion of Strings to StringBuffer and StringBuilder
String to StringBuffer
htaeWsIhtlaeH
String to StringBuilder
HealthIsWeathLikeMoney
*/