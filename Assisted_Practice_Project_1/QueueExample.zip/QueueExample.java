import java.util.*;
public class QueueExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue <String> city = new LinkedList<>();
		city.add("Gurgaon");
		city.add("Ghaziabad");
		city.add("Delhi");
		city.add("Noida");
		city.add("Patna");
		System.out.println("Queue is : " + city);
		System.out.println("Head of Queue : " + city.peek());
		city.remove();
		System.out.println("After removing Head of Queue : " + city);
		System.out.println("Size of Queue : " + city.size());
		city.add("Gurgaon");
		city.add("Ghaziabad");
		System.out.println("Queue is : " + city);
		System.out.println("Head of Queue : " + city.peek());
	}

}
//Output
/*
Queue is : [Gurgaon, Ghaziabad, Delhi, Noida, Patna]
Head of Queue : Gurgaon
After removing Head of Queue : [Ghaziabad, Delhi, Noida, Patna]
Size of Queue : 4
Queue is : [Ghaziabad, Delhi, Noida, Patna, Gurgaon, Ghaziabad]
Head of Queue : Ghaziabad
*/