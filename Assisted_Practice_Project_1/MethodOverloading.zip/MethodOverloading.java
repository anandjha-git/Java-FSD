
public class MethodOverloading {
int calculator(int a, int b){
	return (a+b);
}
int calculator(int a, int b, int c){
	return (a*b +c);
}
int calculator(int r){
	return (r*10);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloading obj = new MethodOverloading();
		System.out.println("Method with one parameter : "+obj.calculator(65));
		System.out.println("Method with two parameter : "+obj.calculator(6, 8));
		System.out.println("Method with three parameter : "+obj.calculator(4,7,5));
		
	}

}

//Outout
/*
Method with one parameter : 650
Method with two parameter : 14
Method with three parameter : 33
*/