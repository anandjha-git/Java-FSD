
public class InsertionSort {
	public static void insertionSort(int[] arr){

	    int len = arr.length;
	    for(int j=1;j<len;j++){
	    int key = arr[j];
	    int i=j-1;
	    while ((i>-1) && (arr[i]>key)){

	        arr[i+1]=arr[i];
	        i--;
	    }
	    arr[i+1]=key;
	         }

	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={2,34,4,5,23,8,21,45,34,37};
		System.out.println("Before Sorting");
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		System.out.println();
		insertionSort(arr);
		System.out.println("After Sorting");
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");


	}

}
//Output
/*
Before Sorting
2 34 4 5 23 8 21 45 34 37 
After Sorting
2 4 5 8 21 23 34 34 37 45 
*/