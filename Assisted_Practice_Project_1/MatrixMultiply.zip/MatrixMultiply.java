
public class MatrixMultiply {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr1[][]={
				{1,2,3},
				{4,5,6}
		};
		int arr2[][]={
				{2,3},
				{4,5},
				{6,7}
		};
		int r1=2,c1=3;
		int r2=3, c2=2;
		if(c1==r2){
			  int[][] result = new int[r1][c2];
			  System.out.println("The Multiplication of two Matrices : ");
		        for(int i = 0; i < r1; i++) {
		            for (int j = 0; j < c2; j++) {
		                for (int k = 0; k < c1; k++) {
		                    result[i][j] += arr1[i][k] * arr2[k][j];
		                }
		                System.out.print(result[i][j]+ " ");
		            }
		            System.out.println();
		        }
		}
		else{
			System.out.println("Matrix Multiplication not possible");
		}

	}

}
//Output
/*
The Multiplication of two Matrices : 
28 34 
64 79 
*/