import java.util.Scanner;
public class LineraSearch {
	public int linearSearch(int arr[], int x){
		for(int i=0;i<arr.length;i++){
			if(arr[i]==x)
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={10,20,30,40,50,60};
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter a number to search  :  ");
		int num = sc.nextInt();
		LineraSearch obj= new LineraSearch();
		int find = obj.linearSearch(arr, num);
		if(find==-1){
			System.out.println("Not Found");
		}
		else{
			System.out.println(num +" is available at "+find+" index.. Thank you");
		}
		
		
	}

}
//Output
/*
Enter a number to search  :  
50
50 is available at 4 index.. Thank you
*/