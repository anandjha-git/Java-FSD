
public class ThrowsDemo {
public int division(int a, int b)throws ArithmeticException{
	return a/b;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowsDemo obj =new ThrowsDemo();
		
		try {
			System.out.println("Division : "+obj.division(18,0));
		}
		catch(ArithmeticException ex){
			System.out.println("Can't Divide by zero' and Error from Machine : " + ex.getMessage() );
		}
	}

}
//Output
/*
Can't Divide by zero' and Error from Machine : / by zero
*/