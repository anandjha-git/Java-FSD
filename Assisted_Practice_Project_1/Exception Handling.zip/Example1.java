class Voting extends Exception{
	public Voting(String message){
		super(message);
	}
}
public class Example1 {
	static void age_validation(int age ) throws Voting{
		if(age<21){
			throw new Voting("You are not allowed for voting ");
		}
		else{
			System.out.println("Welcome to Vote");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			age_validation(19);
		}
		catch (Voting ex){
			System.out.println("Exception Occured");
			System.out.println("Warning : "+ex);
			System.out.println("Thank You");
		}

	}

}
//Output
/*
Exception Occured
Warning : Voting: You are not allowed for voting 
Thank You
*/