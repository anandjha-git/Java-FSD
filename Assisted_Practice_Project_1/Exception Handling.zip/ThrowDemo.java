
public class ThrowDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[5];
		int x=5,y=5;
		try{
			if(y==0)
				throw (new ArithmeticException("Can't divided by zero")); 
			else if(y>4)
				throw (new ArrayIndexOutOfBoundsException("Array out of Bound"));
			else{
				arr[y]=x/y;
				System.out.println("arr[3] = "+arr[y]);
			}
		}
		catch(ArithmeticException ex){
			System.out.println("Error : "+ex.getMessage());
		}
		catch(ArrayIndexOutOfBoundsException ex){
			System.out.println("Error : "+ex.getMessage());
		}
		
	
	}

}
//Output
/*
Error : Array out of Bound
*/