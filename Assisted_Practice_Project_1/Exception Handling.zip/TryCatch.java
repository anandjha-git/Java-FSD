
public class TryCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a []=new int [5];
		int b=1;
		try 
		{
		a[8]=10/b; //Right to left operator preceeding 
		System.out.println(b/0);
		
		}
		
		catch (ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("Array out of Bound");//If b=1, then this will be apply.
		}
		catch (ArithmeticException ex)
		{
			System.out.println("Not allowed by zero");//If b=0,then this will be apply.
		}
		finally{
			System.out.println("Exception Handeled");
		}
	}

}
//Output
/*
Array out of Bound
Exception Handeled
*/