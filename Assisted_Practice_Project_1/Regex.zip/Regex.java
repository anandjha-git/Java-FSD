import java.util.regex.*;

public class Regex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("[abc]"); 
		Matcher m = p.matcher("a7b@z#9");	
		System.out.println("Index  \t Pattern");
		while(m.find()) {
		
			System.out.println(m.start()+"\t"+m.group());
		}
		Pattern p1 = Pattern.compile("[^abc]"); 
		Matcher m1 = p1.matcher("a7b@z#9");	
		System.out.println("Index  \t Pattern");
		while(m1.find()) {
		
			System.out.println(m1.start()+"\t"+m1.group());
		}
		Pattern p2 = Pattern.compile("[0-9]"); 
		Matcher m2 = p2.matcher("a7b@z#9");	
		System.out.println("Index  \t Pattern");
		while(m2.find()) {
		
			System.out.println(m2.start()+"\t"+m2.group());
		}
		//[a-zA-Z0-9]  [^a-zA-Z0-9]  [A-Z]  [^A-Z]  [^0-9]
		Pattern p3 = Pattern.compile("\\."); 
		//   "\\." And "[.]" both are same
		Matcher m3 = p3.matcher("a.7.b.@z#9");	
		System.out.println("Index  \t Pattern");
		while(m3.find()) {
		
			System.out.println(m3.start()+"\t"+m3.group());
		}
	}
}
//Output
/*
Index  	 Pattern
0	a
2	b
Index  	 Pattern
1	7
3	@
4	z
5	#
6	9
Index  	 Pattern
1	7
6	9
Index  	 Pattern
1	.
3	.
5	.
*/