package privateSpecifier;

public class PrivateAccessSpecifier {
	private void display(){
		System.out.println("This is private specifier");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateAccessSpecifier obj = new PrivateAccessSpecifier();
		obj.display();
		NewClass obj1 = new NewClass();
		//obj1.dispaly(); -> Can't be accessed.
	}

}
class NewClass{
	private void display(){
		System.out.println("This is pricate specifier");
	}

}

//Output
/*
This is private specifier
*/