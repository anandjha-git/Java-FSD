package protectedSpecifier3;

public class ProtectedModifier {

	protected int num;
	protected void display(){
		System.out.println("This is Protected Specifier Method");
		System.out.println("This is Protected Variable : "+num);
	}
}
