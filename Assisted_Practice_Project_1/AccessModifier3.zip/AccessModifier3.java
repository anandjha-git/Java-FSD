package protectedSpecifier2;
import protectedSpecifier3.*;
public class AccessModifier3 extends ProtectedModifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifier3 obj =new AccessModifier3();
		obj.num=75;
		obj.display();

	}

}

// Output
/*
This is Protected Specifier Method
This is Protected Variable : 75
*/