
class defAccessSpecifier
{ 
	int num;
  void display() 
     { 
         System.out.println("You are using defalut access specifier"); 
         System.out.println("This is default Variable : "+num);
     } 
} 

public class AccessModifier1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Default Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier();
		obj.num=65;
		obj.display();
	}

}

//Output
/*
Default Access Specifier
You are using defalut access specifier
This is default Variable : 65
*/