
public class LIS {
	public void lis(int arr[], int n){
		int lis[] = new int[n]; 
        int i, j, max = 0;
        for (i = 0; i < n; i++)
            lis[i] = 1; //Put the value 1 in all index
        for (i = 1; i < n; i++)
            for (j = 0; j < i; j++)
                if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
                    lis[i] = lis[j] + 1;
       for (i = 0; i < n; i++)
            if (max < lis[i])
                max = lis[i];
 	System.out.println("Length of LIS is  "+max);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={3,4,-1,0,6,2,3}; // {-1,0,2,3}
		int n=arr.length;
		LIS obj = new LIS();
		obj.lis(arr,n);// {-1,0,2,3}
	}

}
//Output
/*
Length of LIS is  4
*/