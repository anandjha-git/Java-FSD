package publicSpecifier;

public class PubicClass1 {

	public void display(){
		System.out.println("This is Public Specifier");
	}
}
