
public class CallByValue {
	
int callbyvalue(int val){
	val =val*10;
	return val;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=87;
		System.out.println("Value of num before calling callbyvalue method : "+num);
		CallByValue obj = new CallByValue();
		obj.callbyvalue(num);
		System.out.println("Value of num after calling callbyvalue method : "+num);
		System.out.println("The value returned by callbyvalue method : "+obj.callbyvalue(num));
		
	}

}
//Output
/*
Value of num before calling callbyvalue method : 87
Value of num after calling callbyvalue method : 87
The value returned by callbyvalue method : 870
*/