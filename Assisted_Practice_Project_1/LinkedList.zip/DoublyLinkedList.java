
public class DoublyLinkedList {
	static Node head;
	static class Node {
		   
        int data;
        Node prev;
        Node next;
 
        // Constructor
        Node(int data)
        {
            prev=null;
        	this.data = data;
            next = null;
        }
	}
	public void push(int data){
		Node new_node=new Node(data);
		new_node.next=head;
		if(head!=null)
			head.prev=new_node;
		head=new_node;
		printlist();
	}
        public void append(int data){
    		Node new_node=new Node(data);
    		if(head==null)
    			head=new_node;
    		else{
    			Node temp=head;
    			while(temp.next!=null){
    				temp=temp.next;
    			}
    			temp.next=new_node;
    			new_node.prev=temp;
    		}
    	}
 public void InsertAfter(Node prev_Node, int new_data) 
    	{ 
	 	if (prev_Node == null) 
	 		{ 
	 			System.out.println("The given previous node cannot be NULL "); 
            	return; 
        	} 	
		Node new_node = new Node(new_data); 
		new_node.next = prev_Node.next; 
		prev_Node.next = new_node; 
		new_node.prev = prev_Node; 
		if (new_node.next != null) 
		     new_node.next.prev = new_node; 
	} 

	
	public void printlist(){
		if(head==null)
			System.out.println("List is Empty");
		else{
			Node temp=head;
			Node last=head;
			System.out.println("Traversal in forward Direction"); 
			while(temp!=null && last.next != null){
				
				System.out.print(temp.data+" -> ");
				temp=temp.next;
				last=last.next;
			}  
			System.out.println("null");
			System.out.println("Traversal in backward Direction"); 
		
			while(last!=null){
				System.out.print(last.data+" -> ");
				last=last.prev;
			}
			System.out.println("null");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoublyLinkedList list = new DoublyLinkedList();
		list.append(1);
		list.append(2);
		list.append(3);
		list.append(4);
		list.append(5);
		list.push(6);
		list.printlist();
		list.InsertAfter(head.next.next, 8); 
		list.printlist();

	}

	}
//Outpu
/*
Traversal in forward Direction
6 -> 1 -> 2 -> 3 -> 4 -> null
Traversal in backward Direction
5 -> 4 -> 3 -> 2 -> 1 -> 6 -> null
Traversal in forward Direction
6 -> 1 -> 2 -> 3 -> 4 -> null
Traversal in backward Direction
5 -> 4 -> 3 -> 2 -> 1 -> 6 -> null
Traversal in forward Direction
6 -> 1 -> 2 -> 8 -> 3 -> 4 -> null
Traversal in backward Direction
5 -> 4 -> 3 -> 8 -> 2 -> 1 -> 6 -> null
*/