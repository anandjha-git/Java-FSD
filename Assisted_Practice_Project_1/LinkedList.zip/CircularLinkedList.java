
public class CircularLinkedList {
	static class Node 
	{ 
		int data; 
		Node next; 
         	Node(int d) 
    		{ 
        			data = d; 
        			next = null; 
    		} 
	}
	
	Node head; 
	CircularLinkedList()   
	{ 
		head = null; 
	} 
void sortedInsert(int data) 
	{  
		Node new_node= new Node(data); 
    		Node last = head; 
    		if (last == null) 
    		{ 
        			new_node.next = new_node; 
        			head = new_node; 
    		} 
    		else if (last.data >= new_node.data) 
    		{ 
    			while (last.next != head) 
            			last = last.next; 
    			last.next = new_node; 
        		new_node.next = head; 
        		head = new_node; 
    		} 
    		else
    		{
    			while (last.next != head && last.next.data < new_node.data) 
            			last = last.next; 
    				new_node.next = last.next; 
        			last.next = new_node; 
    		} 
}
void print() 
	{ 
    		if (head != null) 
    		{ 
        			Node temp = head; 
        			System.out.println("Elements of Sorted Circular Linked List are :");
        			do
        			{ 
            			System.out.print(temp.data + " -> "); 
            			temp = temp.next; 
        			}  while (temp != head); 
        			
    		} 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircularLinkedList obj =new CircularLinkedList();
		obj.sortedInsert(10);
		obj.sortedInsert(2);
		obj.sortedInsert(12);
		obj.sortedInsert(7);
		obj.sortedInsert(31);
		obj.sortedInsert(4);
		obj.sortedInsert(-2);
		obj.sortedInsert(44);
		obj.print();

	}

}
//output
/*
Elements of Sorted Circular Linked List are :
-2 -> 2 -> 4 -> 7 -> 10 -> 12 -> 31 -> 44 -> 
*/