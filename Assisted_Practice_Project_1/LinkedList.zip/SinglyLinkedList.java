import java.io.*; 
public class SinglyLinkedList {
	Node head;
	static class Node {
		   
        int data;
        Node next;
   
        // Constructor
        Node(int data)
        {
            this.data = data;
            next = null;
        }
    }
	public void insert(int data){
		Node new_node=new Node(data);
		if(head==null)
			head=new_node;
		else{
			Node temp=head;
			while(temp.next!=null){
				temp=temp.next;
			}
			temp.next=new_node;
		}
	}
	public void printlist(){
		if(head==null)
			System.out.println("List is Empty");
		else{
			Node temp=head;
			while(temp!=null){
				System.out.print(temp.data+" -> ");
				temp=temp.next;
			}
			System.out.println("null");
		}
	}
	public void deleteByKey(int key){
		Node temp=head;
		Node prev=null;
		if(head==null){
			System.out.println("List is Empty");
			return ;
		}
		if(temp!=null && temp.data==key){
			head=temp.next;
			System.out.println(key +" is found and deleted");
			return ;
		}
		while(temp.data!=key && temp!=null){
			prev=temp;
			temp=temp.next;
		}
		if(temp==null)
			System.out.println(key + " is not found");
		else{
		prev.next=temp.next;
		System.out.println(key +" is found and deleted");
		}
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SinglyLinkedList list = new SinglyLinkedList();
		list.insert(1);
		list.insert(2);
		list.insert(3);
		list.insert(4);
		list.insert(5);
		list.insert(6);
		list.printlist();
		list.deleteByKey(5);
		list.printlist();
		list.deleteByKey(1);
		list.printlist();
		list.deleteByKey(3);
		list.printlist();
		list.deleteByKey(2);
		list.printlist();
		list.deleteByKey(4);
		list.printlist();
		list.deleteByKey(6);
		list.printlist();
		list.deleteByKey(3);
		list.insert(1);
		list.insert(2);
		list.insert(3);
		list.insert(4);
		list.insert(10);
		list.printlist();
		
	}

}
//Output
/*
1 -> 2 -> 3 -> 4 -> 5 -> 6 -> null
5 is found and deleted
1 -> 2 -> 3 -> 4 -> 6 -> null
1 is found and deleted
2 -> 3 -> 4 -> 6 -> null
3 is found and deleted
2 -> 4 -> 6 -> null
2 is found and deleted
4 -> 6 -> null
4 is found and deleted
6 -> null
6 is found and deleted
List is Empty
List is Empty
1 -> 2 -> 3 -> 4 -> 10 -> null
*/